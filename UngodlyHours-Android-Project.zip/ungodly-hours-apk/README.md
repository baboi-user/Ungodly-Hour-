# Ungodly Hours – Android App

Clean sleep-cycle calculator packaged as a native Android WebView app.

## How to get the APK

1. Create a **new repository** on GitHub (can be private).
2. Upload **all files** from this folder into the repository root.
3. Go to the **Actions** tab → the “Build APK” workflow will run automatically.
4. When it finishes (green check), click the run → **Artifacts** → download `UngodlyHours-debug-apk`.
5. Unzip the downloaded file → you get `app-debug.apk`.
6. Transfer it to your phone and install (enable “Install unknown apps” if needed).

That’s it. No ads, no trackers, no encryption – just your original HTML inside a clean WebView.

### App details
- Package: `com.ungodlyhours.app`
- Min Android: 7.0 (API 24)
- Portrait only
- Dark theme matching the original design
