# Keep everything for WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
